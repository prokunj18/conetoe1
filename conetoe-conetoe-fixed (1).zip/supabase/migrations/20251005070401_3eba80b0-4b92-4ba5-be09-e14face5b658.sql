-- Enable realtime for game_rooms table
ALTER PUBLICATION supabase_realtime ADD TABLE public.game_rooms;