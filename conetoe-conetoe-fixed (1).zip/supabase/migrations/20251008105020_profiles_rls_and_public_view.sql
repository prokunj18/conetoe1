-- Enable RLS on profiles and create safe public view for leaderboard / discovery

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policy: profiles owner can select and update their own profile
CREATE POLICY "Profiles: owner can select" ON public.profiles
FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Profiles: owner can update" ON public.profiles
FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Revoke default public access (make sure public cannot select directly)
REVOKE ALL ON public.profiles FROM public;

-- Create a limited public view for leaderboards / discovery
CREATE OR REPLACE VIEW public.profiles_public AS
SELECT id, username, avatar, level, total_wins, total_games
FROM public.profiles;

GRANT SELECT ON public.profiles_public TO public;

-- Note: server-side functions or service_role should use privileged access to update balances.
