import { useState, useEffect } from 'react';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { AnimatedBackground } from '@/components/ui/animated-background';


const authSchema = {
  signUp: z.object({
    email: z.string().email(),
    password: z.string().min(8).regex(/[A-Z]/, 'Password must include an uppercase letter').regex(/[0-9]/, 'Password must include a number').regex(/[^A-Za-z0-9]/, 'Password must include a special character'),
  }),
  signIn: z.object({
    email: z.string().email(),
    password: z.string().min(8),
  })
};
const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isForgotPassword) {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth?type=recovery`,
        });

        if (error) throw error;

        toast({
          title: 'Password reset email sent!',
          description: 'Check your email and click the link to reset your password',
        });
        setIsForgotPassword(false);
        setLoading(false);
        return;
      }

      if (isLogin) {
        try { authSchema.signIn.parse({ email, password }); } catch (err:any) { toast({ title: 'Invalid input', description: err.errors ? err.errors.map((e:any)=>e.message).join(', ') : err.message, variant: 'destructive' }); setLoading(false); return; }
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) throw error;
        
        toast({ title: 'Welcome back!' });
        navigate('/');
      } else {
        try { authSchema.signUp.parse({ email, password }); } catch (err:any) { toast({ title: 'Invalid input', description: err.errors ? err.errors.map((e:any)=>e.message).join(', ') : err.message, variant: 'destructive' }); setLoading(false); return; }
        if (username.length < 3 || username.length > 16) {
          toast({ 
            title: 'Invalid username', 
            description: 'Username must be 3-16 characters',
            variant: 'destructive'
          });
          setLoading(false);
          return;
        }

        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { username },
            emailRedirectTo: `${window.location.origin}/`
          }
        });

        if (error) throw error;

        toast({ 
          title: 'Account created!',
          description: 'Welcome to CONETOE!'
        });
        navigate('/');
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <AnimatedBackground />
      
      <Card className="w-full max-w-md z-10 bg-card/95 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-center">CONETOE</CardTitle>
          <CardDescription className="text-center">
            {isForgotPassword ? 'Reset your password' : isLogin ? 'Welcome back!' : 'Create your account'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAuth} className="space-y-4">
            {!isLogin && !isForgotPassword && (
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="3-16 characters"
                  minLength={3}
                  maxLength={16}
                  required={!isLogin}
                />
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>

            {!isForgotPassword && (
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  minLength={6}
                  required
                />
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Loading...' : isForgotPassword ? 'Send Reset Link' : isLogin ? 'Sign In' : 'Sign Up'}
            </Button>

            {isLogin && !isForgotPassword && (
              <Button
                type="button"
                variant="link"
                className="w-full text-sm"
                onClick={() => setIsForgotPassword(true)}
              >
                Forgot Password?
              </Button>
            )}

            <Button
              type="button"
              variant="ghost"
              className="w-full"
              onClick={() => {
                if (isForgotPassword) {
                  setIsForgotPassword(false);
                } else {
        try { authSchema.signUp.parse({ email, password }); } catch (err:any) { toast({ title: 'Invalid input', description: err.errors ? err.errors.map((e:any)=>e.message).join(', ') : err.message, variant: 'destructive' }); setLoading(false); return; }
                  setIsLogin(!isLogin);
                }
              }}
            >
              {isForgotPassword ? 'Back to Sign In' : isLogin ? "Don't have an account? Sign Up" : 'Already have an account? Sign In'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
